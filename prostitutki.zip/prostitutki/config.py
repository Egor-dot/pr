token='1722073868:AAHAanM51SVGrmpzIyqlTKvsugHdC92cAOI'
admin=1652924621

minimalka = 450
maximalka = 20000
vxodadmin='D9xan' #Слово для входа в админ панель (Доступно только для админов)
vxodworker='/working'#Слово для входа в воркер панель (Доступно только для всех)
zalety = -1001211893148 
bot_username = "LoosyPussy_bot"


poderjka = "@GwweenBlade" #аккаунт техподдержки

maxpromo = 5000 #максимальная сумма промокода которую могут создать воркеры


